function setup() {
  createCanvas(500, 300);
}

function draw() {
  background(218,165,32)
  
  fill(240,248,255);
  textSize(30);
  textStyle(BOLD);
  text("Consciência Negra" ,40,100);

  textSize(20);
  textStyle(NORMAL);
  text("Literatura" , 125, 130);
       
}





  





